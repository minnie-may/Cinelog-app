import { useEffect, useState } from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";
import { HEADER_HEIGHT } from "../../../theme/tokens";
import { getReviews } from "../api";
import ReviewCard from "../components/ReviewCard";
import { Review } from "../types";

export default function ReviewsScreen() {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    let isMounted = true;

    getReviews()
      .then((data) => {
        if (isMounted) setReviews(data);
      })
      .catch((error) => console.log(error));

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Movie Reviews</Text>

      <FlatList
        data={reviews}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ReviewCard item={item} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
    paddingHorizontal: 16,
    paddingTop: HEADER_HEIGHT + 8,
  },
  title: {
    color: "white",
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
  },
});
