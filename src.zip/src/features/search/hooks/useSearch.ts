import { useState } from "react";
import { searchMovies } from "../api";
import { SearchMovie } from "../types";

export function useSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchMovie[]>([]);

  async function search() {
    if (!query.trim()) return;

    try {
      setResults(await searchMovies(query.trim()));
    } catch (error) {
      console.log(error);
    }
  }

  return {
    query,
    setQuery,
    results,
    search,
  };
}
